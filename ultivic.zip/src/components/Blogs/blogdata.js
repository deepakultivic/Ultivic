const blogdata =[
    {   
        id:"1",
        blog_imgs:"/assets/home/blog-1.jpg",
        tittle :"A wonderful serenity Loreum",
        description:"Exercitation photo booth stumptown tote bag Banksy, elit small batch freegan sed Craft beer elit...",
        blog_link:"Continue reading",
        date:"APRIL 9, 2021",
        slug:"A-wonderful-serenity-Loreum"
    },
    {
        id:"2",
        blog_imgs:"/assets/home/blog-1.jpg",
        tittle :"A wonderful Loreum serenity",
        description:"Exercitation photo booth stumptown tote bag Banksy, elit small batch freegan sed Craft beer elit...",
        blog_link:"Continue reading",
        date:"APRIL 9, 2021",
        slug:"A-serenit-ywonderful-Loreum"
    },
    {
        id:"3",
        blog_imgs:"/assets/home/blog-1.jpg",
        tittle :"A wonderful serenity Loreum",
        description:"Exercitation photo booth stumptown tote bag Banksy, elit small batch freegan sed Craft beer elit...",
        blog_link:"Continue reading",
        date:"APRIL 9, 2021",
        slug:"A-wonderful-serenity-Loreum"
    },
]
export default blogdata;