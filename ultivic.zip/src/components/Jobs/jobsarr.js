const jobsarr =[
    {
        
        jobTitle:"Magento Developer",
        joblink:"Apply Now",
        joblocation:"Mohali",
        jobdescription:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        updatedtime:'2h'
    },
    {
        
        jobTitle:"Dotnet+ReactJS Developer",
        joblink:"Apply Now",
        joblocation:"Mohali",
        jobdescription:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        updatedtime:'2h'
    },
    {
        
        jobTitle:"Magento Developer",
        joblink:"Apply Now",
        joblocation:"Mohali",
        jobdescription:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        updatedtime:'2h'
    },
    {
        
        jobTitle:"Data Entry",
        joblink:"Apply Now",
        joblocation:"Mohali",
        jobdescription:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        updatedtime:'2h'
    },
    {
        
        jobTitle:"Android Developer",
        joblink:"Apply Now",
        joblocation:"Mohali",
        jobdescription:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        updatedtime:'2h'
    },
    {
        
        jobTitle:"IOS Developer",
        joblink:"Apply Now",
        joblocation:"Mohali",
        jobdescription:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        updatedtime:'2h'
    },
]
export default jobsarr;